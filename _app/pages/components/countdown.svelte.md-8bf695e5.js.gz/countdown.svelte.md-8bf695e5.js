import{S as lt,i as ot,s as pt,C as tt,w as z,x as B,y as H,z as ct,A as st,q as F,o as G,B as K,J as ut,v as rt,a9 as nt,e as f,t as S,k as R,c as d,a as i,h as b,d as p,m as k,g as N,H as c,f as P,b as h,a1 as U,j as W,O as X}from"../../chunks/vendor-55159dd6.js";import{M as ft}from"../../chunks/_markdown-b92f8e53.js";import{C as dt,a as Q,p as it,r as Z}from"../../chunks/actions-758c9310.js";import"../../chunks/stores-9ae8bf36.js";import"../../chunks/Ads-555a7cc0.js";import"../../chunks/util-862dcf5d.js";import"../../chunks/SEO-8062c077.js";import"../../chunks/preload-helper-ec9aa979.js";function vt(v){let t,s;return{c(){t=f("span"),s=f("span"),this.h()},l(a){t=d(a,"SPAN",{class:!0});var l=i(t);s=d(l,"SPAN",{style:!0}),i(s).forEach(p),l.forEach(p),this.h()},h(){P(s,"--value",v[0]),h(t,"class","countdown")},m(a,l){N(a,t,l),c(t,s)},p(a,l){l&1&&P(s,"--value",a[0])},d(a){a&&p(t)}}}function mt(v){let t,s=`<span class="$$countdown">
  <span style="--value:${v[0]};"></span>
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown">
  <span style="--value:${e[0]};"></span>
</span>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function $t(v){let t,s;return{c(){t=f("span"),s=f("span"),this.h()},l(a){t=d(a,"SPAN",{class:!0});var l=i(t);s=d(l,"SPAN",{style:!0}),i(s).forEach(p),l.forEach(p),this.h()},h(){P(s,"--value",v[0]),h(t,"class","countdown font-mono text-6xl")},m(a,l){N(a,t,l),c(t,s)},p(a,l){l&1&&P(s,"--value",a[0])},d(a){a&&p(t)}}}function xt(v){let t,s=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${v[0]};"></span>
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown font-mono text-6xl">
  <span style="--value:${e[0]};"></span>
</span>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function ht(v){let t,s,a,l,u,r,e;return{c(){t=f("span"),s=f("span"),a=S(`h
  `),l=f("span"),u=S(`m
  `),r=f("span"),e=S("s"),this.h()},l(n){t=d(n,"SPAN",{class:!0});var x=i(t);s=d(x,"SPAN",{style:!0}),i(s).forEach(p),a=b(x,`h
  `),l=d(x,"SPAN",{style:!0}),i(l).forEach(p),u=b(x,`m
  `),r=d(x,"SPAN",{style:!0}),i(r).forEach(p),e=b(x,"s"),x.forEach(p),this.h()},h(){P(s,"--value","10"),P(l,"--value","24"),P(r,"--value",v[0]),h(t,"class","font-mono text-2xl countdown")},m(n,x){N(n,t,x),c(t,s),c(t,a),c(t,l),c(t,u),c(t,r),c(t,e)},p(n,x){x&1&&P(r,"--value",n[0])},d(n){n&&p(t)}}}function _t(v){let t,s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${v[0]};"></span>s
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>h
  <span style="--value:24;"></span>m
  <span style="--value:${e[0]};"></span>s
</span>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function wt(v){let t,s,a,l,u,r;return{c(){t=f("span"),s=f("span"),a=S(`:
  `),l=f("span"),u=S(`:
  `),r=f("span"),this.h()},l(e){t=d(e,"SPAN",{class:!0});var n=i(t);s=d(n,"SPAN",{style:!0}),i(s).forEach(p),a=b(n,`:
  `),l=d(n,"SPAN",{style:!0}),i(l).forEach(p),u=b(n,`:
  `),r=d(n,"SPAN",{style:!0}),i(r).forEach(p),n.forEach(p),this.h()},h(){P(s,"--value","10"),P(l,"--value","24"),P(r,"--value",v[0]),h(t,"class","font-mono text-2xl countdown")},m(e,n){N(e,t,n),c(t,s),c(t,a),c(t,l),c(t,u),c(t,r)},p(e,n){n&1&&P(r,"--value",e[0])},d(e){e&&p(t)}}}function Et(v){let t,s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${v[0]};"></span>
</span>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<span class="$$countdown font-mono text-2xl">
  <span style="--value:10;"></span>:
  <span style="--value:24;"></span>:
  <span style="--value:${e[0]};"></span>
</span>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function gt(v){let t,s,a,l,u,r,e,n,x,J,D,y,E,V,I,L,w,A,g,M;return{c(){t=f("div"),s=f("div"),a=f("span"),l=f("span"),u=S(`
    days`),r=R(),e=f("div"),n=f("span"),x=f("span"),J=S(`
    hours`),D=R(),y=f("div"),E=f("span"),V=f("span"),I=S(`
    minutes`),L=R(),w=f("div"),A=f("span"),g=f("span"),M=S(`
    sec`),this.h()},l(_){t=d(_,"DIV",{class:!0});var $=i(t);s=d($,"DIV",{});var o=i(s);a=d(o,"SPAN",{class:!0});var m=i(a);l=d(m,"SPAN",{style:!0}),i(l).forEach(p),m.forEach(p),u=b(o,`
    days`),o.forEach(p),r=k($),e=d($,"DIV",{});var C=i(e);n=d(C,"SPAN",{class:!0});var q=i(n);x=d(q,"SPAN",{style:!0}),i(x).forEach(p),q.forEach(p),J=b(C,`
    hours`),C.forEach(p),D=k($),y=d($,"DIV",{});var T=i(y);E=d(T,"SPAN",{class:!0});var O=i(E);V=d(O,"SPAN",{style:!0}),i(V).forEach(p),O.forEach(p),I=b(T,`
    minutes`),T.forEach(p),L=k($),w=d($,"DIV",{});var j=i(w);A=d(j,"SPAN",{class:!0});var Y=i(A);g=d(Y,"SPAN",{style:!0}),i(g).forEach(p),Y.forEach(p),M=b(j,`
    sec`),j.forEach(p),$.forEach(p),this.h()},h(){P(l,"--value","15"),h(a,"class","font-mono text-4xl countdown"),P(x,"--value","10"),h(n,"class","font-mono text-4xl countdown"),P(V,"--value","24"),h(E,"class","font-mono text-4xl countdown"),P(g,"--value",v[0]),h(A,"class","font-mono text-4xl countdown"),h(t,"class","flex gap-5")},m(_,$){N(_,t,$),c(t,s),c(s,a),c(a,l),c(s,u),c(t,r),c(t,e),c(e,n),c(n,x),c(e,J),c(t,D),c(t,y),c(y,E),c(E,V),c(y,I),c(t,L),c(t,w),c(w,A),c(A,g),c(w,M)},p(_,$){$&1&&P(g,"--value",_[0])},d(_){_&&p(t)}}}function yt(v){let t,s=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${v[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<div class="flex gap-5">
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div>
    <span class="$$countdown font-mono text-4xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function Pt(v){let t,s,a,l,u,r,e,n,x,J,D,y,E,V,I,L,w,A,g,M;return{c(){t=f("div"),s=f("div"),a=f("span"),l=f("span"),u=S(`
    days`),r=R(),e=f("div"),n=f("span"),x=f("span"),J=S(`
    hours`),D=R(),y=f("div"),E=f("span"),V=f("span"),I=S(`
    min`),L=R(),w=f("div"),A=f("span"),g=f("span"),M=S(`
    sec`),this.h()},l(_){t=d(_,"DIV",{class:!0});var $=i(t);s=d($,"DIV",{class:!0});var o=i(s);a=d(o,"SPAN",{class:!0});var m=i(a);l=d(m,"SPAN",{style:!0}),i(l).forEach(p),m.forEach(p),u=b(o,`
    days`),o.forEach(p),r=k($),e=d($,"DIV",{class:!0});var C=i(e);n=d(C,"SPAN",{class:!0});var q=i(n);x=d(q,"SPAN",{style:!0}),i(x).forEach(p),q.forEach(p),J=b(C,`
    hours`),C.forEach(p),D=k($),y=d($,"DIV",{class:!0});var T=i(y);E=d(T,"SPAN",{class:!0});var O=i(E);V=d(O,"SPAN",{style:!0}),i(V).forEach(p),O.forEach(p),I=b(T,`
    min`),T.forEach(p),L=k($),w=d($,"DIV",{class:!0});var j=i(w);A=d(j,"SPAN",{class:!0});var Y=i(A);g=d(Y,"SPAN",{style:!0}),i(g).forEach(p),Y.forEach(p),M=b(j,`
    sec`),j.forEach(p),$.forEach(p),this.h()},h(){P(l,"--value","15"),h(a,"class","font-mono text-5xl countdown"),h(s,"class","flex flex-col"),P(x,"--value","10"),h(n,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(y,"class","flex flex-col"),P(g,"--value",v[0]),h(A,"class","font-mono text-5xl countdown"),h(w,"class","flex flex-col"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(_,$){N(_,t,$),c(t,s),c(s,a),c(a,l),c(s,u),c(t,r),c(t,e),c(e,n),c(n,x),c(e,J),c(t,D),c(t,y),c(y,E),c(E,V),c(y,I),c(t,L),c(t,w),c(w,A),c(A,g),c(w,M)},p(_,$){$&1&&P(g,"--value",_[0])},d(_){_&&p(t)}}}function St(v){let t,s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${v[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function bt(v){let t,s,a,l,u,r,e,n,x,J,D,y,E,V,I,L,w,A,g,M;return{c(){t=f("div"),s=f("div"),a=f("span"),l=f("span"),u=S(`
    days`),r=R(),e=f("div"),n=f("span"),x=f("span"),J=S(`
    hours`),D=R(),y=f("div"),E=f("span"),V=f("span"),I=S(`
    min`),L=R(),w=f("div"),A=f("span"),g=f("span"),M=S(`
    sec`),this.h()},l(_){t=d(_,"DIV",{class:!0});var $=i(t);s=d($,"DIV",{class:!0});var o=i(s);a=d(o,"SPAN",{class:!0});var m=i(a);l=d(m,"SPAN",{style:!0}),i(l).forEach(p),m.forEach(p),u=b(o,`
    days`),o.forEach(p),r=k($),e=d($,"DIV",{class:!0});var C=i(e);n=d(C,"SPAN",{class:!0});var q=i(n);x=d(q,"SPAN",{style:!0}),i(x).forEach(p),q.forEach(p),J=b(C,`
    hours`),C.forEach(p),D=k($),y=d($,"DIV",{class:!0});var T=i(y);E=d(T,"SPAN",{class:!0});var O=i(E);V=d(O,"SPAN",{style:!0}),i(V).forEach(p),O.forEach(p),I=b(T,`
    min`),T.forEach(p),L=k($),w=d($,"DIV",{class:!0});var j=i(w);A=d(j,"SPAN",{class:!0});var Y=i(A);g=d(Y,"SPAN",{style:!0}),i(g).forEach(p),Y.forEach(p),M=b(j,`
    sec`),j.forEach(p),$.forEach(p),this.h()},h(){P(l,"--value","15"),h(a,"class","font-mono text-5xl countdown"),h(s,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(x,"--value","10"),h(n,"class","font-mono text-5xl countdown"),h(e,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(V,"--value","24"),h(E,"class","font-mono text-5xl countdown"),h(y,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),P(g,"--value",v[0]),h(A,"class","font-mono text-5xl countdown"),h(w,"class","flex flex-col p-2 bg-neutral rounded-box text-neutral-content"),h(t,"class","grid grid-flow-col gap-5 text-center auto-cols-max")},m(_,$){N(_,t,$),c(t,s),c(s,a),c(a,l),c(s,u),c(t,r),c(t,e),c(e,n),c(n,x),c(e,J),c(t,D),c(t,y),c(y,E),c(E,V),c(y,I),c(t,L),c(t,w),c(w,A),c(A,g),c(w,M)},p(_,$){$&1&&P(g,"--value",_[0])},d(_){_&&p(t)}}}function At(v){let t,s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${v[0]};"></span>
    </span>
    sec
  </div>
</div>`,a,l,u,r;return{c(){t=f("pre"),a=S(s),this.h()},l(e){t=d(e,"PRE",{slot:!0});var n=i(t);a=b(n,s),n.forEach(p),this.h()},h(){h(t,"slot","html")},m(e,n){N(e,t,n),c(t,a),u||(r=U(l=Z.call(null,t,{to:v[1]})),u=!0)},p(e,n){n&1&&s!==(s=`<div class="grid grid-flow-col gap-5 text-center auto-cols-max">
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:15;"></span>
    </span>
    days
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:10;"></span>
    </span>
    hours
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:24;"></span>
    </span>
    min
  </div> 
  <div class="flex flex-col p-2 bg-neutral rounded-box text-neutral-content">
    <span class="$$countdown font-mono text-5xl">
      <span style="--value:${e[0]};"></span>
    </span>
    sec
  </div>
</div>`)&&W(a,s),l&&X(l.update)&&n&2&&l.update.call(null,{to:e[1]})},d(e){e&&p(t),u=!1,r()}}}function Nt(v){let t,s,a,l,u,r,e,n,x,J,D,y,E,V,I,L,w,A,g,M,_,$;return e=new dt({props:{data:[{type:"component",class:"countdown",desc:"Container element"}]}}),x=new Q({props:{title:"Countdown",$$slots:{html:[mt],default:[vt]},$$scope:{ctx:v}}}),D=new Q({props:{title:"Large text",$$slots:{html:[xt],default:[$t]},$$scope:{ctx:v}}}),E=new Q({props:{title:"Clock countdown",$$slots:{html:[_t],default:[ht]},$$scope:{ctx:v}}}),I=new Q({props:{title:"Clock countdown with colons",$$slots:{html:[Et],default:[wt]},$$scope:{ctx:v}}}),w=new Q({props:{title:"Large text with labels",$$slots:{html:[yt],default:[gt]},$$scope:{ctx:v}}}),g=new Q({props:{title:"Large text with labels under",$$slots:{html:[St],default:[Pt]},$$scope:{ctx:v}}}),_=new Q({props:{title:"In boxes",$$slots:{html:[At],default:[bt]},$$scope:{ctx:v}}}),{c(){t=f("p"),s=S("You need to change to "),a=f("code"),l=S("--value"),u=S(" CSS variable using JS. Value must be a number between 0 and 99"),r=R(),z(e.$$.fragment),n=R(),z(x.$$.fragment),J=R(),z(D.$$.fragment),y=R(),z(E.$$.fragment),V=R(),z(I.$$.fragment),L=R(),z(w.$$.fragment),A=R(),z(g.$$.fragment),M=R(),z(_.$$.fragment)},l(o){t=d(o,"P",{});var m=i(t);s=b(m,"You need to change to "),a=d(m,"CODE",{});var C=i(a);l=b(C,"--value"),C.forEach(p),u=b(m," CSS variable using JS. Value must be a number between 0 and 99"),m.forEach(p),r=k(o),B(e.$$.fragment,o),n=k(o),B(x.$$.fragment,o),J=k(o),B(D.$$.fragment,o),y=k(o),B(E.$$.fragment,o),V=k(o),B(I.$$.fragment,o),L=k(o),B(w.$$.fragment,o),A=k(o),B(g.$$.fragment,o),M=k(o),B(_.$$.fragment,o)},m(o,m){N(o,t,m),c(t,s),c(t,a),c(a,l),c(t,u),N(o,r,m),H(e,o,m),N(o,n,m),H(x,o,m),N(o,J,m),H(D,o,m),N(o,y,m),H(E,o,m),N(o,V,m),H(I,o,m),N(o,L,m),H(w,o,m),N(o,A,m),H(g,o,m),N(o,M,m),H(_,o,m),$=!0},p(o,m){const C={};m&19&&(C.$$scope={dirty:m,ctx:o}),x.$set(C);const q={};m&19&&(q.$$scope={dirty:m,ctx:o}),D.$set(q);const T={};m&19&&(T.$$scope={dirty:m,ctx:o}),E.$set(T);const O={};m&19&&(O.$$scope={dirty:m,ctx:o}),I.$set(O);const j={};m&19&&(j.$$scope={dirty:m,ctx:o}),w.$set(j);const Y={};m&19&&(Y.$$scope={dirty:m,ctx:o}),g.$set(Y);const et={};m&19&&(et.$$scope={dirty:m,ctx:o}),_.$set(et)},i(o){$||(F(e.$$.fragment,o),F(x.$$.fragment,o),F(D.$$.fragment,o),F(E.$$.fragment,o),F(I.$$.fragment,o),F(w.$$.fragment,o),F(g.$$.fragment,o),F(_.$$.fragment,o),$=!0)},o(o){G(e.$$.fragment,o),G(x.$$.fragment,o),G(D.$$.fragment,o),G(E.$$.fragment,o),G(I.$$.fragment,o),G(w.$$.fragment,o),G(g.$$.fragment,o),G(_.$$.fragment,o),$=!1},d(o){o&&p(t),o&&p(r),K(e,o),o&&p(n),K(x,o),o&&p(J),K(D,o),o&&p(y),K(E,o),o&&p(V),K(I,o),o&&p(L),K(w,o),o&&p(A),K(g,o),o&&p(M),K(_,o)}}}function Vt(v){let t,s;const a=[v[2],at];let l={$$slots:{default:[Nt]},$$scope:{ctx:v}};for(let u=0;u<a.length;u+=1)l=tt(l,a[u]);return t=new ft({props:l}),{c(){z(t.$$.fragment)},l(u){B(t.$$.fragment,u)},m(u,r){H(t,u,r),s=!0},p(u,[r]){const e=r&4?ct(a,[r&4&&st(u[2]),r&0&&st(at)]):{};r&19&&(e.$$scope={dirty:r,ctx:u}),t.$set(e)},i(u){s||(F(t.$$.fragment,u),s=!0)},o(u){G(t.$$.fragment,u),s=!1},d(u){K(t,u)}}}const at={title:"Countdown",desc:"Countdown gives you a transition effect of changing numbers",published:!0};function Dt(v,t,s){let a;ut(v,it,r=>s(1,a=r));let l=59;function u(){l>0?(s(0,l--,l),setTimeout(u,1e3)):(s(0,l=59),setTimeout(u,1e3))}return rt(()=>{u()}),v.$$set=r=>{s(2,t=tt(tt({},t),nt(r)))},t=nt(t),[l,a,t]}class jt extends lt{constructor(t){super();ot(this,t,Dt,Vt,pt,{})}}export{jt as default,at as metadata};
